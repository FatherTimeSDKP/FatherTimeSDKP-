
# TimeSeal Legacy NFT – Mint Execution Kit

## Contract Info
- Address: 0xdb7d379Cab99B6C96c102Ab44FDBcB14C3898302
- Network: Ethereum Mainnet (Chain ID: 1)
- NFT Metadata: ipfs://QmcctTE7rhGh4iG9QQiXQPTQoE3qnDzxdea6aB4H1sCjaG

## Minting Steps
1. Log into the admin wallet (0x9E83...100) via thirdweb dashboard.
2. Navigate to the batch upload panel.
3. Ensure metadata is set.
4. Fund recipient wallet (0x45D5...A82) with at least 0.06 ETH.
5. Mint and confirm via wallet.
6. Verify NFT on OpenSea or Etherscan.

## Embed Instructions
Open `TimeSeal-Legacy-NFT.html` and use or host it for public mint access.
